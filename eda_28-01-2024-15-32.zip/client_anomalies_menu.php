<table width="99%" border="0">
  <tr>
    <td width="26%"><div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">Probleme à resoudre</h3>
      </div>
      <div class="panel-body"> <a class="btn btn-sm btn-default" type="button" href="client_anomalies_resoudre.php"> Ajouter une intervension </a></div>
    </div></td>
    <td width="2%">&nbsp;</td>
    <td width="34%"><div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">Problemes resolus</h3>
      </div>
      <div class="panel-body"> <a class="btn btn-sm btn-default" type="button" href="client_anomalies_finaliser.php"> Archives </a></div>
    </div></td>
    <td width="2%">&nbsp;</td>
    <td width="36%"><div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">Id_Client, Id_demande , Description</h3>
      </div>
      <div class="panel-body">
        <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td width="47%"><table width="100%" border="0.5" cellspacing="0" cellpadding="0">
              <tr>
                <td width="52%"><form action="client_anomalies_chercher.php" method="post" name="form1" id="form2">
                  <label for="mr1"></label>
                  <input name="mr1" type="text" id="mr1" size="30" />
                  <input type="submit" name="Cherchez " id="Cherchez " class="btn btn-sm btn-default"value="Chercher détail" />
                </form></td>
              </tr>
            </table></td>
          </tr>
        </table>
      </div>
    </div></td>
  </tr>
</table>
