    
     <a href="client_document.php?id=<?php echo md5(microtime()).$datam['id'];?>" class="btn btn-sm btn-success" > Ajouter des documents </a>
     |
     
     <a href="co_affichage.php" class="btn btn-sm btn-danger" > Annuler </a>
     | 