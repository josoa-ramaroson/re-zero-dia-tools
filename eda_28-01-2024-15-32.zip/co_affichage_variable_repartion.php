<?php

// SOURCE 
$RefCommune='301';
$RefLocalite='30101';
$ville='MUTSAMUDU VILLE';
$RefQuartier='3010114';
$quartier='SANGANI';

// repartion numro 1

$RefLocalite_1='30101';
$RefQuartier_1='3010119';
$quartier_1='DINDRIHARI';


// repartion numro 2

$RefLocalite_2='';
$RefQuartier_2='';
$quartier_2='';


?>

