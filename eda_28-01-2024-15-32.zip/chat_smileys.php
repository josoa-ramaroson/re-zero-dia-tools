<?
//$message = str_replace(':)' ,'<img src="smileys/0100.gif"/>',$message);

$message = str_replace('sourire' ,'<img src="smileys/1.gif" width=25 height=25 />',$message);
$message = str_replace(':)' ,'<img src="smileys/1.gif" width=25 height=25 />',$message);

$message = str_replace('triste' ,'<img src="smileys/1.gif" width=25 height=25 />',$message);
$message = str_replace(':(' ,'<img src="smileys/2.gif" width=25 height=25 />',$message);

$message = str_replace('rigole' ,'<img src="smileys/3.gif" width=25 height=25/>',$message);
$message = str_replace(':d' ,'<img src="smileys/3.gif"  width=25 height=25/>',$message);


$message = str_replace('cool' ,'<img src="smileys/4.gif" width=25 height=25/>',$message);


$message = str_replace('Clin d œil' ,'<img src="smileys/5.gif" width=25 height=25/>',$message);
$message = str_replace(';)' ,'<img src="smileys/5.gif" width=25 height=25/>',$message);

$message = str_replace('surpris' ,'<img src="smileys/6.gif" width=25 height=25/>',$message);
$message = str_replace(':o' ,'<img src="smileys/6.gif" width=25 height=25/>',$message);


$message = str_replace('pleurs' ,'<img src="smileys/7.gif" width=25 height=25/>',$message);
$message = str_replace(';(' ,'<img src="smileys/7.gif" width=25 height=25/>',$message);

$message = str_replace('transpirant' ,'<img src="smileys/8.gif" width=25 height=25/>',$message);



$message = str_replace('Bouche bée' ,'<img src="smileys/9.gif" width=25 height=25/>',$message);
$message = str_replace(':|' ,'<img src="smileys/9.gif" width=25 height=25/>',$message);


$message = str_replace('bisou' ,'<img src="smileys/10.gif" width=25 height=25/>',$message);
$message = str_replace('(k)' ,'<img src="smileys/10.gif" width=25 height=25/>',$message);



$message = str_replace('Insolent' ,'<img src="smileys/11.gif" width=25 height=25/>',$message);
$message = str_replace(':p' ,'<img src="smileys/11.gif" width=25 height=25/>',$message);


$message = str_replace('croise les doigts' ,'<img src="smileys/12.gif" width=25 height=25/>',$message);
$message = str_replace('(yn)' ,'<img src="smileys/12.gif" width=25 height=25/>',$message);

$message = str_replace('rougi' ,'<img src="smileys/13.gif" width=25 height=25/>',$message);
$message = str_replace(':$' ,'<img src="smileys/13.gif" width=25 height=25/>',$message);


$message = str_replace('se demande' ,'<img src="smileys/14.gif" width=25 height=25/>',$message);
$message = str_replace(':^)' ,'<img src="smileys/14.gif" width=25 height=25/>',$message);


$message = str_replace('endormi' ,'<img src="smileys/15.gif" width=25 height=25/>',$message);
$message = str_replace('|-)' ,'<img src="smileys/15.gif" width=25 height=25/>',$message);



$message = str_replace('ennuyeux' ,'<img src="smileys/16.gif" width=25 height=25/>',$message);
$message = str_replace('=(' ,'<img src="smileys/16.gif" width=25 height=25/>',$message);


$message = str_replace('amoureux' ,'<img src="smileys/17.gif" width=25 height=25/>',$message);
$message = str_replace('(inlove)' ,'<img src="smileys/17.gif" width=25 height=25/>',$message);


$message = str_replace('diabolique' ,'<img src="smileys/18.gif" width=25 height=25/>',$message);

$message = str_replace('baille' ,'<img src="smileys/19.gif" width=25 height=25/>',$message);

$message = str_replace('vomit' ,'<img src="smileys/20.gif" width=25 height=25/>',$message);
$message = str_replace('D oh' ,'<img src="smileys/21.gif" width=25 height=25/>',$message);
$message = str_replace('en colère' ,'<img src="smileys/22.gif" width=25 height=25/>',$message);
$message = str_replace('C était pas moi ' ,'<img src="smileys/23.gif" width=25 height=25/>',$message);

$message = str_replace('fête' ,'<img src="smileys/24.gif" width=25 height=25/>',$message);
$message = str_replace('Rhoo' ,'<img src="smileys/25.gif" width=25 height=25/>',$message);
$message = str_replace('inquiet' ,'<img src="smileys/26.gif" width=25 height=25/>',$message);

$message = str_replace('mmmm' ,'<img src="smileys/27.gif" width=25 height=25/>',$message);
$message = str_replace('Intello' ,'<img src="smileys/28.gif" width=25 height=25/>',$message);
$message = str_replace('bouche cousue' ,'<img src="smileys/29.gif" width=25 height=25/>',$message);


$message = str_replace('salut' ,'<img src="smileys/30.gif" width=25 height=25/>',$message);
$message = str_replace('diable' ,'<img src="smileys/31.gif" width=25 height=25/>',$message);
$message = str_replace('ange' ,'<img src="smileys/32.gif" width=25 height=25/>',$message);
$message = str_replace('envieux' ,'<img src="smileys/33.gif" width=25 height=25/>',$message);
$message = str_replace('attends' ,'<img src="smileys/34.gif" width=25 height=25/>',$message);
$message = str_replace('calin' ,'<img src="smileys/35.gif" width=25 height=25/>',$message);



$message = str_replace('maquillage' ,'<img src="smileys/36.gif" width=25 height=25/>',$message);
$message = str_replace('moustache' ,'<img src="smileys/37.gif" width=25 height=25/>',$message);
$message = str_replace('rire' ,'<img src="smileys/38.gif" width=25 height=25/>',$message);
$message = str_replace('bravo' ,'<img src="smileys/39.gif" width=25 height=25/>',$message);
$message = str_replace('penif' ,'<img src="smileys/40.gif" width=25 height=25/>',$message);
$message = str_replace('courbette' ,'<img src="smileys/41.gif" width=25 height=25/>',$message);


$message = str_replace('mdr' ,'<img src="smileys/42.gif" width=25 height=25/>',$message);
$message = str_replace('ouf' ,'<img src="smileys/43.gif" width=25 height=25/>',$message);
$message = str_replace('(highfive)' ,'<img src="smileys/44.gif" width=25 height=25/>',$message);
$message = str_replace('content' ,'<img src="smileys/45.gif" width=25 height=25/>',$message);
$message = str_replace('(smirk)' ,'<img src="smileys/46.gif" width=25 height=25/>',$message);
$message = str_replace('acquiescement' ,'<img src="smileys/47.gif" width=25 height=25/>',$message);


$message = str_replace('secoué' ,'<img src="smileys/48.gif" width=25 height=25/>',$message);
$message = str_replace('en attente' ,'<img src="smileys/49.gif" width=25 height=25/>',$message);
$message = str_replace('(emo)' ,'<img src="smileys/50.gif" width=25 height=25/>',$message);
$message = str_replace('oui' ,'<img src="smileys/51.gif" width=25 height=25/>',$message);
$message = str_replace('nom' ,'<img src="smileys/52.gif" width=25 height=25/>',$message);
$message = str_replace('handshake' ,'<img src="smileys/53.gif" width=25 height=25/>',$message);


$message = str_replace('coeur' ,'<img src="smileys/54.gif" width=25 height=25/>',$message);
$message = str_replace('lalala' ,'<img src="smileys/55.gif" width=25 height=25/>',$message);
$message = str_replace('(tmi)' ,'<img src="smileys/56.gif" width=25 height=25/>',$message);
$message = str_replace('ecureuil' ,'<img src="smileys/57.gif" width=25 height=25/>',$message);
$message = str_replace('(f)' ,'<img src="smileys/58.gif" width=25 height=25/>',$message);
$message = str_replace('pluie' ,'<img src="smileys/59.gif" width=25 height=25/>',$message);

?>
