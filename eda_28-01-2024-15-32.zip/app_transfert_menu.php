<table width="99%" border="0">
  <tr>
    <td width="51%"><div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">Suvi des transferts des produits entre les magasins</h3>
      </div>
      <div class="panel-body"> 
      <a class="btn btn-sm btn-default" type="button" href="app_transfert_etape1.php"> Sortie Magasin Production </a>|
      <a class="btn btn-sm btn-default" type="button" href="app_transfert_etape2.php"> Entre  Magasin Vente </a>|
      <a class="btn btn-sm btn-default" type="button" href="app_transfert_etape3.php"> Archives </a>|
    
     </div>
    </div></td>
    <td width="3%">&nbsp;</td>
    <td width="8%">&nbsp;</td>
    <td width="2%">&nbsp;</td>
    <td width="36%"><div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">Numero, Login agent, Description </h3>
      </div>
      <div class="panel-body">
        <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td width="47%"><table width="100%" border="0.5" cellspacing="0" cellpadding="0">
              <tr>
                <td width="52%"><form action="#" method="post" name="form1" id="form2">
                  <label for="mr1"></label>
                  <input name="mr1" type="text" id="mr1" size="30" />
                  <input type="submit" name="Cherchez " id="Cherchez " class="btn btn-sm btn-default"value="Chercher détail" />
                </form></td>
              </tr>
            </table></td>
          </tr>
        </table>
      </div>
    </div></td>
  </tr>
</table>
