	  <?php
      if ($u_niveau==1) $type='clientèle';
	  if ($u_niveau==2) $type='Facturation'; 
	  if ($u_niveau==3) $type='Recouvrement';
	  if ($u_niveau==4) $type='Paiement'; 
	  if ($u_niveau==5) $type='Releveur'; 
	  if ($u_niveau==6) $type='Resp Caisse'; 
	  if ($u_niveau==7) $type='Admin Systeme'; 
	  if ($u_niveau==8) $type='Resp Facturation'; 
	  if ($u_niveau==9) $type='Resp Recouvrement'; 
	  if ($u_niveau==10) $type='TInformatique';
	  if ($u_niveau==20) $type='Comptabilite';  
	  if ($u_niveau==30) $type='Communication';
	  if ($u_niveau==40) $type='Approvisionnement'; 
	  if ($u_niveau==41) $type='Gaz'; 
	  if ($u_niveau==42) $type='Devis & Branchement';
	  if ($u_niveau==43) $type='resp Commercial';  
	  if ($u_niveau==44) $type='Serv Controle'; 
	  if ($u_niveau==45) $type='Magasin'; 
	  if ($u_niveau==46) $type='Admin Commercial';
	  if ($u_niveau==47) $type='Laboratoire';
	  if ($u_niveau==50) $type='Serv Personnel'; 
	  if ($u_niveau==60) $type='Serv Distribution';
	  if ($u_niveau==70) $type='Serv Production';  
	  if ($u_niveau==80) $type='Statistique'; 
	  if ($u_niveau==90) $type='R&D'; 
	  if ($u_niveau==91) $type='Suivi MT et plus';
      ?>