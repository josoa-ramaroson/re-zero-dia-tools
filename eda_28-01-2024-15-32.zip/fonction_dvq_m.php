<html>
<head>

<script type="text/javascript">
function AjaxFunction()
{
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
		  try
   			 		{
   				 httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    				}
  			catch (e)
    				{
    			try
      		{
      		httpxml=new ActiveXObject("Microsoft.XMLHTTP");
     		 }
    			catch (e)
      		{
      		alert("Your browser does not support AJAX!");
      		return false;
      		}
    		}
  }
function stateck() 
    {
    if(httpxml.readyState==4)
      {
//alert(httpxml.responseText);
var myarray = JSON.parse(httpxml.responseText);
// Remove the options from 2nd dropdown list 
for(j=document.testform.subcat.options.length-1;j>=0;j--)
{
document.testform.subcat.remove(j);
}


for (i=0;i<myarray.data.length;i++)
{
var optn = document.createElement("OPTION");
optn.text = myarray.data[i].quartier;
optn.value = myarray.data[i].id_quartier;  // You can change this to subcategory 
document.testform.subcat.options.add(optn);

} 
      }
    } // end of function stateck
	var url="fonction_dvq.php";
var refville=document.getElementById('s1').value;
url=url+"?refville="+refville;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateck;
//alert(url);
httpxml.open("GET",url,true);
httpxml.send(null);
  }
</script>
</head>
<body>
<form name="testform" method='POST' action=''>
  <?Php
require "fonction.php";// connection to database 

echo "<br>Ville  <select name=cat id='s1' onchange=AjaxFunction();>
<option value=''>Choisissez une ville</option>";

$sql="select refville, ville from ville "; // Query to collect data from table 

$result = mysqli_query($linki, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<option value='" . $row['refville'] . "'>" . $row['ville'] . "</option>";
    }
} else {
    echo "Erreur lors de la requête : " . mysqli_error($linki);
}
?>
</select>
<br>
Quartier 
<select name=subcat id='s2'>

</select><br><input type=submit value=submit>
</form>
<center></center> 
</body>
</html>